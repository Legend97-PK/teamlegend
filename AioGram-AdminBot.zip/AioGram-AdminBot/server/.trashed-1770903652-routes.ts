import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import multer from "multer";
import { z } from "zod";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // --- AI Integrations ---
  registerChatRoutes(app);
  registerImageRoutes(app);

  // --- Settings Routes ---
  app.get(api.settings.list.path, async (req, res) => {
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.post(api.settings.update.path, async (req, res) => {
    const { key } = req.params;
    const { value } = req.body;
    const updated = await storage.updateSetting(key, value);
    res.json(updated);
  });

  // --- Files Routes ---
  app.get(api.files.list.path, async (req, res) => {
    const files = await storage.getFiles();
    res.json(files);
  });

  app.post(api.files.upload.path, upload.single('file'), async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const content = req.file.buffer.toString('utf-8');
    const lines = content.split('\n').map(l => l.trim()).filter(l => l.length > 0);

    if (lines.length === 0) {
      return res.status(400).json({ message: "File is empty" });
    }

    const file = await storage.createFile({ filename: req.file.originalname });
    
    // Insert numbers
    const numbersData = lines.map(line => ({
      fileId: file.id,
      content: line,
      isUsed: false
    }));
    
    await storage.createNumbers(numbersData);

    res.status(201).json(file);
  });

  app.delete(api.files.delete.path, async (req, res) => {
    const id = Number(req.params.id);
    await storage.deleteFile(id);
    res.status(204).send();
  });

  // --- Number Consumption Route ---
  app.post(api.numbers.get.path, async (req, res) => {
    const { fileId } = req.body;
    const nums = await storage.getThreeNumbers(fileId);
    
    if (nums.length === 0) {
       return res.status(404).json({ message: "No numbers available in this file" });
    }
    
    res.json({ numbers: nums });
  });

  // --- Commands Routes ---
  app.get("/api/commands", async (req, res) => {
    const commands = await storage.getCommands();
    res.json(commands);
  });

  app.post("/api/commands", async (req, res) => {
    try {
      const command = await storage.createCommand(req.body);
      res.status(201).json(command);
    } catch (err) {
      res.status(400).json({ message: "Command already exists or invalid data" });
    }
  });

  app.patch("/api/commands/:id", async (req, res) => {
    const id = Number(req.params.id);
    const command = await storage.updateCommand(id, req.body);
    res.json(command);
  });

  app.delete("/api/commands/:id", async (req, res) => {
    const id = Number(req.params.id);
    await storage.deleteCommand(id);
    res.status(204).send();
  });

  app.post("/api/broadcast", async (req, res) => {
    const { message } = req.body;
    if (!message) return res.status(400).json({ message: "Message is required" });

    const users = await storage.getBotUsers();
    let success = 0;
    let fail = 0;

    for (const user of users) {
      try {
        if (bot) {
          await bot.telegram.sendMessage(user.telegramId, message, { parse_mode: "Markdown" });
          success++;
        }
      } catch (err) {
        fail++;
      }
    }

    res.json({ success, fail });
  });

  return httpServer;
}

// Seed initial settings if empty
async function seedSettings() {
  const defaults = {
    'bot_name': 'TEAM LEGENDS',
    'support_text': 'Support: @support',
    'otpgroup_text': 'OTP Group: @otpgroup',
    'folder_text': 'Folder: https://t.me/folderlink',
    'refresh_text': 'Refresh Numbers 🔄',
    'change_country_text': 'Change Country 🌍',
    'get_number_command': 'GET NUMBER ☎️',
    'welcome_text': '👋 Welcome, {mention}! Glad to have you in TEAM LEGENDS 💗',
  };

  for (const [key, value] of Object.entries(defaults)) {
    const existing = await storage.getSetting(key);
    if (!existing) {
      await storage.updateSetting(key, value);
    }
  }
}

// Call seed on startup (async, don't await blocking)
seedSettings().catch(console.error);
