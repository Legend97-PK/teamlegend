import { db } from "./db";
import {
  settings,
  numberFiles,
  numbers,
  botUsers,
  type Setting,
  type NumberFile,
  type PhoneNumber,
  type BotUser,
  type InsertSetting,
  type InsertNumberFile,
  type InsertPhoneNumber,
  type InsertBotUser,
} from "@shared/schema";
import { eq, sql, and } from "drizzle-orm";

export interface IStorage {
  // Users
  getBotUser(telegramId: string): Promise<BotUser | undefined>;
  upsertBotUser(user: InsertBotUser): Promise<BotUser>;
  getBotUsersCount(): Promise<number>;

  // Settings
  getSettings(): Promise<Setting[]>;
  getSetting(key: string): Promise<Setting | undefined>;
  updateSetting(key: string, value: string): Promise<Setting>;

  // Files
  getFiles(): Promise<(NumberFile & { availableCount: number })[]>;
  getFile(id: number): Promise<NumberFile | undefined>;
  createFile(file: InsertNumberFile): Promise<NumberFile>;
  deleteFile(id: number): Promise<void>;

  // Numbers
  createNumbers(numbersData: InsertPhoneNumber[]): Promise<void>;
  getThreeNumbers(fileId: number): Promise<string[]>;

  // Broadcast
  getBotUsers(): Promise<BotUser[]>;
}

export class DatabaseStorage implements IStorage {
  async getBotUsers(): Promise<BotUser[]> {
    return await db.select().from(botUsers);
  }

  async getCommands(): Promise<Command[]> {
    return await db.select().from(commands);
  }

  async getCommand(command: string): Promise<Command | undefined> {
    const [result] = await db.select().from(commands).where(and(eq(commands.command, command), eq(commands.isActive, true)));
    return result;
  }

  async createCommand(command: InsertCommand): Promise<Command> {
    const [result] = await db.insert(commands).values(command).returning();
    return result;
  }

  async updateCommand(id: number, updates: Partial<InsertCommand>): Promise<Command> {
    const [result] = await db.update(commands).set(updates).where(eq(commands.id, id)).returning();
    return result;
  }

  async deleteCommand(id: number): Promise<void> {
    await db.delete(commands).where(eq(commands.id, id));
  }

  async getBotUser(telegramId: string): Promise<BotUser | undefined> {
    const [user] = await db.select().from(botUsers).where(eq(botUsers.telegramId, telegramId));
    return user;
  }

  async upsertBotUser(insertUser: InsertBotUser): Promise<BotUser> {
    try {
      const existing = await this.getBotUser(insertUser.telegramId);
      if (existing) {
        const [updated] = await db
          .update(botUsers)
          .set({
            username: insertUser.username,
            firstName: insertUser.firstName,
            lastName: insertUser.lastName,
          })
          .where(eq(botUsers.telegramId, insertUser.telegramId))
          .returning();
        return updated;
      }
      const [created] = await db.insert(botUsers).values(insertUser).returning();
      return created;
    } catch (error) {
      console.error("Error in upsertBotUser:", error);
      throw new Error(`Failed to upsert bot user: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }

  async getBotUsersCount(): Promise<number> {
    const [result] = await db.select({ count: sql<number>`count(*)` }).from(botUsers);
    return Number(result.count);
  }

  async getSettings(): Promise<Setting[]> {
    return await db.select().from(settings);
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.key, key));
    return setting;
  }

  async updateSetting(key: string, value: string): Promise<Setting> {
    // Upsert behavior
    const existing = await this.getSetting(key);
    if (existing) {
      const [updated] = await db
        .update(settings)
        .set({ value })
        .where(eq(settings.key, key))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(settings)
        .values({ key, value })
        .returning();
      return created;
    }
  }

  async getFiles(): Promise<(NumberFile & { availableCount: number })[]> {
    const files = await db.select().from(numberFiles);
    
    // This could be optimized with a join and group by, but for simplicity looping is fine for small scale
    const filesWithStats = await Promise.all(files.map(async (file) => {
        const [countResult] = await db
            .select({ count: sql<number>`count(*)` })
            .from(numbers)
            .where(and(eq(numbers.fileId, file.id), eq(numbers.isUsed, false)));
        return { ...file, availableCount: Number(countResult.count) };
    }));

    return filesWithStats;
  }

  async getFile(id: number): Promise<NumberFile | undefined> {
    const [file] = await db.select().from(numberFiles).where(eq(numberFiles.id, id));
    return file;
  }

  async createFile(file: InsertNumberFile): Promise<NumberFile> {
    const [created] = await db.insert(numberFiles).values(file).returning();
    return created;
  }

  async deleteFile(id: number): Promise<void> {
    // Cascade delete numbers (or use DB cascade, but we'll do it explicit here for safety)
    await db.delete(numbers).where(eq(numbers.fileId, id));
    await db.delete(numberFiles).where(eq(numberFiles.id, id));
  }

  async createNumbers(numbersData: InsertPhoneNumber[]): Promise<void> {
    if (numbersData.length === 0) return;
    // Batch insert
    // Drizzle/PG can handle large batches, but safer to chunk if massive. 
    // Assuming reasonable file sizes for now.
    await db.insert(numbers).values(numbersData);
  }

  async getThreeNumbers(fileId: number): Promise<string[]> {
    return await db.transaction(async (tx) => {
      // Lock rows or just select limit 3 not used
      const available = await tx
        .select()
        .from(numbers)
        .where(and(eq(numbers.fileId, fileId), eq(numbers.isUsed, false)))
        .limit(3);
      
      if (available.length === 0) return [];

      const ids = available.map(n => n.id);
      
      // Mark as used
      await tx
        .update(numbers)
        .set({ isUsed: true, usedAt: new Date() })
        .where(sql`${numbers.id} IN ${ids}`);
      
      // To be safe and simple:
      for (const item of available) {
         await tx.update(numbers).set({ isUsed: true, usedAt: new Date() }).where(eq(numbers.id, item.id));
      }

      return available.map(n => n.content);
    });
  }
}

export const storage = new DatabaseStorage();
