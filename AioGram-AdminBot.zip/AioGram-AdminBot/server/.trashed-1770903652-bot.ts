import { Telegraf, Context } from "telegraf";
import { storage } from "./storage";
import OpenAI from "openai";

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const ADMIN_ID = process.env.ADMIN_ID;

if (!BOT_TOKEN) {
  console.warn("TELEGRAM_BOT_TOKEN not found. Bot will not start.");
}

export const bot = BOT_TOKEN ? new Telegraf(BOT_TOKEN) : null;

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

if (bot) {
  const isAdmin = (ctx: Context) => {
    return ctx.from?.id.toString() === ADMIN_ID;
  };

  bot.use(async (ctx, next) => {
    try {
      if (ctx.from) {
        await storage.upsertBotUser({
          telegramId: ctx.from.id.toString(),
          username: ctx.from.username || null,
          firstName: ctx.from.first_name || null,
          lastName: ctx.from.last_name || null,
        });
      }
    } catch (err) {
      console.error("Error upserting bot user:", err);
    }
    return next();
  });

  bot.start(async (ctx) => {
    const botName = (await storage.getSetting("bot_name"))?.value || "TEAM LEGENDS";
    
    if (isAdmin(ctx)) {
      const keyboard = {
        reply_markup: {
          keyboard: [
            [{ text: "📊 Stats" }, { text: "📢 Broadcast" }],
            [{ text: "📝 Manage Commands" }, { text: "⚙️ Settings" }],
            [{ text: "📂 Number Files" }, { text: "👋 Welcome Msg" }],
            [{ text: "❌ Close" }]
          ],
          resize_keyboard: true
        }
      };
      ctx.reply(`👑 Admin Panel - ${botName}\n\nSelect an option to manage your bot:`, keyboard);
    } else {
      const getNumberCmd = (await storage.getSetting("get_number_command"))?.value || "GET NUMBER ☎️";
      const supportCmd = "SUPPORT 🏪";
      const otpGroupCmd = "OTP GROUP 💝";
      const folderCmd = "FOLDER 📂";

      const keyboard = {
        reply_markup: {
          keyboard: [
            [{ text: getNumberCmd }],
            [{ text: "Ask AI" }],
            [{ text: supportCmd }, { text: otpGroupCmd }, { text: folderCmd }]
          ],
          resize_keyboard: true
        }
      };
      ctx.reply(`Welcome to ${botName}!\nUse the menu below or commands to interact.`, keyboard);
    }
  });

  bot.hears("📊 Stats", async (ctx) => {
    if (!isAdmin(ctx)) return;
    const userCount = await storage.getBotUsersCount();
    const files = await storage.getFiles();
    const totalNumbers = files.reduce((acc, f) => acc + f.availableCount, 0);
    
    ctx.reply(`📈 *Bot Statistics*\n\n👥 Total Users: ${userCount}\n📂 Total Files: ${files.length}\n☎️ Available Numbers: ${totalNumbers}`, { parse_mode: "Markdown" });
  });

  bot.hears("📢 Broadcast", async (ctx) => {
    if (!isAdmin(ctx)) return;
    ctx.reply("Please send the message you want to broadcast to ALL users.\n\nType 'cancel' to stop.");
    // In a real app, you'd use a scene or state machine here. 
    // For simplicity, we'll just prompt them to use the web panel or /broadcast command if we had it.
    ctx.reply("Tip: You can use the Web Admin Panel for easier broadcasting with Markdown support.");
  });

  bot.hears("📝 Manage Commands", async (ctx) => {
    if (!isAdmin(ctx)) return;
    const commands = await storage.getCommands();
    if (commands.length === 0) return ctx.reply("No custom commands found.");
    
    const list = commands.map(c => `/${c.command} - ${c.message.substring(0, 30)}...`).join("\n");
    ctx.reply(`🛠 *Custom Commands*\n\n${list}\n\nUse the Web Panel to add or remove commands.`, { parse_mode: "Markdown" });
  });

  bot.hears("⚙️ Settings", async (ctx) => {
    if (!isAdmin(ctx)) return;
    ctx.reply("Select a setting to update:", {
      reply_markup: {
        keyboard: [
          [{ text: "Set Bot Name" }, { text: "Set Support Info" }],
          [{ text: "Set OTP Group" }, { text: "Set Folder Link" }],
          [{ text: "🔙 Back" }]
        ],
        resize_keyboard: true
      }
    });
  });

  bot.hears("👋 Welcome Msg", async (ctx) => {
    if (!isAdmin(ctx)) return;
    const current = (await storage.getSetting("welcome_text"))?.value || "Not set";
    ctx.reply(`Current Welcome Message:\n\n${current}\n\nTo update, use: /setwelcome [message]`);
  });

  bot.hears("❌ Close", async (ctx) => {
    if (!isAdmin(ctx)) return;
    ctx.reply("Admin panel closed.", { reply_markup: { remove_keyboard: true } });
  });

  bot.hears("🔙 Back", async (ctx) => {
    if (!isAdmin(ctx)) return;
    return bot.handleUpdate(ctx.update); // Trigger /start again
  });

  bot.hears("Ask AI", async (ctx) => {
    ctx.reply("Send me your question starting with /ai. For example: /ai what is a phone number?");
  });

  bot.hears("Upload Number File", async (ctx) => {
    if (!isAdmin(ctx)) return;
    ctx.reply("Please use the web interface to upload files for now, or send a .txt file here.");
  });

  bot.on("document", async (ctx) => {
    if (!isAdmin(ctx)) return;
    const doc = ctx.message.document;
    if (!doc.file_name?.endsWith(".txt")) {
      return ctx.reply("Only .txt files are allowed.");
    }

    try {
      const fileLink = await bot.telegram.getFileLink(doc.file_id);
      const response = await fetch(fileLink.href);
      const content = await response.text();
      const lines = content.split("\n").map(l => l.trim()).filter(l => l.length > 0);

      if (lines.length === 0) {
        return ctx.reply("File is empty.");
      }

      const file = await storage.createFile({ filename: doc.file_name });
      const numbersData = lines.map(line => ({
        fileId: file.id,
        content: line,
        isUsed: false
      }));
      await storage.createNumbers(numbersData);

      ctx.reply(`File '${doc.file_name}' uploaded successfully with ${lines.length} numbers.`);
    } catch (err) {
      console.error("Error handling document upload:", err);
      ctx.reply("Failed to process the file.");
    }
  });

  bot.hears("List Number Files", async (ctx) => {
    if (!isAdmin(ctx)) return;
    const files = await storage.getFiles();
    if (files.length === 0) {
      return ctx.reply("No number files uploaded.");
    }
    const list = files.map(f => `${f.filename}: ${f.availableCount} available`).join("\n");
    ctx.reply(`Number files:\n${list}`);
  });

  bot.hears("Delete Number File", async (ctx) => {
    if (!isAdmin(ctx)) return;
    const files = await storage.getFiles();
    if (files.length === 0) {
      return ctx.reply("No files to delete.");
    }
    const keyboard = {
      inline_keyboard: files.map(f => [{ text: `Delete ${f.filename}`, callback_data: `del_${f.id}` }])
    };
    ctx.reply("Select file to delete:", { reply_markup: keyboard });
  });

  bot.hears(/Set (.+)/, async (ctx) => {
    if (!isAdmin(ctx)) return;
    const match = ctx.message.text.match(/Set (.+)/);
    if (!match) return;
    const settingName = match[1];
    const keyMap: Record<string, string> = {
      "Bot Name": "bot_name",
      "Support Info": "support",
      "OTP Group": "otp_group",
      "Folder Link": "folder",
      "Refresh Text": "refresh_text",
      "Change Country Text": "change_country_text"
    };
    const key = keyMap[settingName];
    if (key) {
      ctx.reply(`Send the new value for ${settingName}:`);
    }
  });

  bot.on("text", async (ctx) => {
    const text = ctx.message.text.trim();
    const getNumberCmd = (await storage.getSetting("get_number_command"))?.value || "GET NUMBER ☎️";
    
    // Check for custom commands
    if (text.startsWith("/")) {
      const cmdName = text.slice(1).split(" ")[0];
      const customCmd = await storage.getCommand(cmdName);
      if (customCmd) {
        return ctx.reply(customCmd.message, { parse_mode: "Markdown" });
      }
    }

    // Check for AI prompt
    if (text.startsWith("/ai")) {
      const prompt = text.replace("/ai", "").trim();
      if (!prompt) return ctx.reply("Please provide a prompt for the AI.");

      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5.1",
          messages: [{ role: "user", content: prompt }],
          max_completion_tokens: 1024,
        });

        const aiResponse = response.choices[0]?.message?.content || "No response from AI.";
        return ctx.reply(aiResponse);
      } catch (err) {
        console.error("AI Chat error:", err);
        return ctx.reply("Sorry, I'm having trouble connecting to my AI brain right now.");
      }
    }

    if (text === getNumberCmd || text === "/getnumber") {
      const files = await storage.getFiles();
      if (files.length === 0) {
        return ctx.reply("No number files available.");
      }
      const keyboard = {
        inline_keyboard: files.map((f) => [
          { text: `${f.filename} (${f.availableCount})`, callback_data: `get_${f.id}` },
        ]),
      };
      return ctx.reply("Select a service to get numbers:", { reply_markup: keyboard });
    }

  bot.command("support", async (ctx) => {
    const support = (await storage.getSetting("support_text"))?.value || "Support: @support";
    ctx.reply(support, { parse_mode: "Markdown" });
  });

  bot.command("otpgroup", async (ctx) => {
    const otpGroup = (await storage.getSetting("otpgroup_text"))?.value || "OTP Group: @otpgroup";
    ctx.reply(otpGroup, { parse_mode: "Markdown" });
  });

  bot.command("folder", async (ctx) => {
    const folder = (await storage.getSetting("folder_text"))?.value || "Folder: https://t.me/folderlink";
    ctx.reply(folder, { parse_mode: "Markdown" });
  });

  bot.hears("SUPPORT 🏪", async (ctx) => {
    const support = (await storage.getSetting("support_text"))?.value || "Support: @support";
    ctx.reply(support, { parse_mode: "Markdown" });
  });

  bot.hears("OTP GROUP 💝", async (ctx) => {
    const otpGroup = (await storage.getSetting("otpgroup_text"))?.value || "OTP Group: @otpgroup";
    ctx.reply(otpGroup, { parse_mode: "Markdown" });
  });

  bot.hears("FOLDER 📂", async (ctx) => {
    const folder = (await storage.getSetting("folder_text"))?.value || "Folder: https://t.me/folderlink";
    ctx.reply(folder, { parse_mode: "Markdown" });
  });
  });

  bot.on("callback_query", async (ctx) => {
    const data = (ctx.callbackQuery as any).data;
    if (data?.startsWith("get_")) {
      const fileId = parseInt(data.split("_")[1]);
      const nums = await storage.getThreeNumbers(fileId);
      
      if (nums.length === 0) {
        return ctx.answerCbQuery("No numbers available in this file.", { show_alert: true });
      }

      await ctx.answerCbQuery();
      ctx.reply(`Your numbers:\n\n${nums.join("\n")}`);
    } else if (data?.startsWith("del_")) {
      if (!isAdmin(ctx)) return ctx.answerCbQuery("Admin only.");
      const fileId = parseInt(data.split("_")[1]);
      await storage.deleteFile(fileId);
      await ctx.answerCbQuery("File deleted.");
      ctx.editMessageText("File deleted successfully.");
    }
  });

  bot.on("new_chat_members", async (ctx) => {
    const welcomeText = (await storage.getSetting("welcome_text"))?.value;
    if (!welcomeText) return;

    for (const member of ctx.message.new_chat_members) {
      const mention = member.username ? `@${member.username}` : member.first_name;
      let text = welcomeText.replace("{mention}", mention);
      
      const buttons: { text: string; url: string }[] = [];
      const buttonRegex = /\[(.*?)\]\(buttonurl:(.*?)\)/g;
      let match;
      while ((match = buttonRegex.exec(text)) !== null) {
        buttons.push({ text: match[1], url: match[2] });
      }
      
      const cleanText = text.replace(buttonRegex, "").trim();

      if (buttons.length > 0) {
        const keyboard = {
          inline_keyboard: [] as any[]
        };
        for (let i = 0; i < buttons.length; i += 2) {
          keyboard.inline_keyboard.push(buttons.slice(i, i + 2).map(b => ({ text: b.text, url: b.url })));
        }
        ctx.reply(cleanText, { reply_markup: keyboard, parse_mode: "Markdown" }).catch(console.error);
      } else {
        ctx.reply(text, { parse_mode: "Markdown" }).catch(console.error);
      }
    }
  });

  bot.command("setwelcome", async (ctx) => {
    if (ctx.from?.id.toString() !== ADMIN_ID) return;
    const text = ctx.message.text.replace("/setwelcome", "").trim();
    if (!text) return ctx.reply("Please provide the welcome text.");
    
    await storage.updateSetting("welcome_text", text);
    ctx.reply("Welcome message updated!");
  });

  bot.launch().catch((err) => {
    if (err.response?.error_code === 403) {
      console.warn("Telegram bot was blocked by a user, skipping start message.");
    } else {
      console.error("Failed to launch Telegram bot:", err);
    }
  });

  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
}
