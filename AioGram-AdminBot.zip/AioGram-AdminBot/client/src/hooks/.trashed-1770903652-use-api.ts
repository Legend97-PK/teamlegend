import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type UpdateSettingRequest, type InsertSetting, type InsertNumberFile } from "@shared/schema";

// ============================================
// SETTINGS HOOKS
// ============================================

export function useSettings() {
  return useQuery({
    queryKey: [api.settings.list.path],
    queryFn: async () => {
      const res = await fetch(api.settings.list.path);
      if (!res.ok) throw new Error('Failed to fetch settings');
      return api.settings.list.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateSetting() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ key, value }: { key: string; value: string }) => {
      const url = buildUrl(api.settings.update.path, { key });
      const res = await fetch(url, {
        method: api.settings.update.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value }),
      });
      
      if (!res.ok) {
        throw new Error('Failed to update setting');
      }
      return api.settings.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.settings.list.path] });
    },
  });
}

// ============================================
// FILES HOOKS
// ============================================

export function useFiles() {
  return useQuery({
    queryKey: [api.files.list.path],
    queryFn: async () => {
      const res = await fetch(api.files.list.path);
      if (!res.ok) throw new Error('Failed to fetch files');
      return api.files.list.responses[200].parse(await res.json());
    },
  });
}

export function useUploadFile() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch(api.files.upload.path, {
        method: api.files.upload.method,
        body: formData,
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.files.upload.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error('Failed to upload file');
      }
      return api.files.upload.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.files.list.path] });
    },
  });
}

export function useDeleteFile() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.files.delete.path, { id });
      const res = await fetch(url, { method: api.files.delete.method });
      
      if (!res.ok) {
        if (res.status === 404) throw new Error('File not found');
        throw new Error('Failed to delete file');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.files.list.path] });
    },
  });
}

// ============================================
// NUMBERS HOOKS
// ============================================

export function useGetNumbers() {
  return useMutation({
    mutationFn: async ({ fileId }: { fileId: number }) => {
      const res = await fetch(api.numbers.get.path, {
        method: api.numbers.get.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileId }),
      });
      
      if (!res.ok) {
        if (res.status === 404) throw new Error('No numbers available or file not found');
        throw new Error('Failed to fetch numbers');
      }
      return api.numbers.get.responses[200].parse(await res.json());
    },
  });
}
