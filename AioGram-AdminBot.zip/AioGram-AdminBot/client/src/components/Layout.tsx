import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Settings, Phone, ShieldCheck, Heart, FolderOpen, LogOut } from "lucide-react";
import { useSettings } from "@/hooks/use-api";
import { clsx } from "clsx";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { data: settings } = useSettings();
  
  const botName = settings?.find(s => s.key === 'bot_name')?.value || "Team Legends";
  const support = settings?.find(s => s.key === 'support')?.value;
  const otpGroup = settings?.find(s => s.key === 'otp_group')?.value;
  const folder = settings?.find(s => s.key === 'folder')?.value;

  const isAdmin = location.startsWith("/admin");

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-900 via-[#0a0a0a] to-black text-white selection:bg-primary/30">
      {/* Navigation */}
      <nav className="border-b border-white/10 sticky top-0 z-50 bg-background/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-lg shadow-primary/20">
                <span className="font-mono font-bold text-lg">TL</span>
              </div>
              <Link href="/" className="font-display font-bold text-xl tracking-tight hover:opacity-80 transition-opacity">
                {botName}
              </Link>
            </div>

            <div className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
              {support && (
                <div className="flex items-center gap-2 hover:text-white transition-colors cursor-default">
                  <Heart className="w-4 h-4 text-rose-500" />
                  <span>{support}</span>
                </div>
              )}
              {otpGroup && (
                <div className="flex items-center gap-2 hover:text-white transition-colors cursor-default">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>{otpGroup}</span>
                </div>
              )}
              {folder && (
                <a href={folder.replace('Folder: ', '')} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-white transition-colors">
                  <FolderOpen className="w-4 h-4 text-blue-500" />
                  <span>Folder</span>
                </a>
              )}
            </div>

            <div className="flex items-center gap-4">
              <Link href={isAdmin ? "/" : "/admin"} className={clsx(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                isAdmin 
                  ? "text-muted-foreground hover:text-white hover:bg-white/5" 
                  : "bg-white/5 hover:bg-white/10 text-white border border-white/10"
              )}>
                {isAdmin ? (
                  <>
                    <LogOut className="w-4 h-4" />
                    <span>Exit Admin</span>
                  </>
                ) : (
                  <>
                    <Settings className="w-4 h-4" />
                    <span>Admin Panel</span>
                  </>
                )}
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {children}
        </motion.div>
      </main>
      
      {/* Footer */}
      <footer className="border-t border-white/5 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} {botName}. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
