import { ReactNode } from "react";
import { motion } from "framer-motion";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: string;
  trendUp?: boolean;
}

export function StatsCard({ title, value, icon, trend, trendUp }: StatsCardProps) {
  return (
    <motion.div 
      whileHover={{ y: -4 }}
      className="glass-card p-6 rounded-2xl relative overflow-hidden group"
    >
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity scale-150 transform translate-x-2 -translate-y-2">
        {icon}
      </div>
      
      <div className="flex flex-col gap-1 relative z-10">
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <h3 className="text-3xl font-display font-bold text-white tracking-tight">{value}</h3>
        {trend && (
          <div className={`flex items-center gap-1 text-xs font-medium mt-1 ${trendUp ? 'text-emerald-400' : 'text-rose-400'}`}>
            <span>{trend}</span>
          </div>
        )}
      </div>
    </motion.div>
  );
}
