import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { useFiles, useSettings, useUpdateSetting, useUploadFile, useDeleteFile } from "@/hooks/use-api";
import { StatsCard } from "@/components/StatsCard";
import { 
  Upload, FileText, Trash2, Save, Activity, 
  Settings2, Bot, Heart, Shield, Folder, Plus, Send, Terminal
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Command } from "@shared/schema";

export default function Admin() {
  const { data: files } = useFiles();
  const { data: settings } = useSettings();
  const { data: commands, refetch: refetchCommands } = useQuery<Command[]>({ queryKey: ["/api/commands"] });
  const updateSetting = useUpdateSetting();
  const uploadFile = useUploadFile();
  const deleteFile = useDeleteFile();
  const { toast } = useToast();
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const [newCmd, setNewCmd] = useState({ command: "", message: "" });

  const broadcastMutation = useMutation({
    mutationFn: async (message: string) => {
      const res = await apiRequest("POST", "/api/broadcast", { message });
      return res.json();
    },
    onSuccess: (data) => {
      toast({ description: `Broadcast sent: ${data.success} success, ${data.fail} failed.` });
      setBroadcastMsg("");
    }
  });

  const addCommandMutation = useMutation({
    mutationFn: async (cmd: { command: string; message: string }) => {
      await apiRequest("POST", "/api/commands", cmd);
    },
    onSuccess: () => {
      toast({ description: "Command added successfully" });
      setNewCmd({ command: "", message: "" });
      refetchCommands();
    }
  });

  const deleteCommandMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/commands/${id}`);
    },
    onSuccess: () => {
      toast({ description: "Command deleted" });
      refetchCommands();
    }
  });

  const updateCommandMutation = useMutation({
    mutationFn: async ({ id, ...cmd }: { id: number; command: string; message: string }) => {
      await apiRequest("PATCH", `/api/commands/${id}`, cmd);
    },
    onSuccess: () => {
      toast({ description: "Command updated" });
      refetchCommands();
    }
  });

  // Stats
  const totalFiles = files?.length || 0;
  const totalNumbers = files?.reduce((acc, f) => acc + f.availableCount, 0) || 0;

  // Handlers
  const handleSettingUpdate = async (key: string, value: string) => {
    try {
      await updateSetting.mutateAsync({ key, value });
      toast({ description: "Setting updated successfully" });
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Failed to update setting", 
        variant: "destructive" 
      });
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    
    const formData = new FormData();
    formData.append("file", e.target.files[0]);

    try {
      await uploadFile.mutateAsync(formData);
      toast({ description: "File uploaded successfully" });
      if (fileInputRef.current) fileInputRef.current.value = "";
    } catch (error: any) {
      toast({ 
        title: "Error", 
        description: error.message, 
        variant: "destructive" 
      });
    }
  };

  const handleDeleteFile = async (id: number) => {
    if (!confirm("Are you sure you want to delete this file? This action cannot be undone.")) return;
    try {
      await deleteFile.mutateAsync(id);
      toast({ description: "File deleted successfully" });
    } catch (error) {
      toast({ description: "Failed to delete file", variant: "destructive" });
    }
  };

  return (
    <Layout>
      <div className="space-y-8 pb-20">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-white">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-1">Manage your bot and number files.</p>
          </div>
          
          <div className="flex gap-3">
            <Button 
              onClick={() => fileInputRef.current?.click()}
              className="bg-primary hover:bg-primary/90 text-white gap-2"
              disabled={uploadFile.isPending}
            >
              <Upload className="w-4 h-4" />
              {uploadFile.isPending ? "Uploading..." : "Upload Numbers"}
            </Button>
            <input 
              type="file" 
              accept=".txt" 
              className="hidden" 
              ref={fileInputRef}
              onChange={handleFileUpload}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard 
            title="Total Files" 
            value={totalFiles} 
            icon={<FileText className="w-8 h-8" />} 
            trendUp={true}
          />
          <StatsCard 
            title="Available Numbers" 
            value={totalNumbers.toLocaleString()} 
            icon={<Activity className="w-8 h-8" />} 
          />
        </div>

        <Tabs defaultValue="files" className="space-y-6">
          <TabsList className="bg-white/5 border border-white/10 p-1">
            <TabsTrigger value="files" className="data-[state=active]:bg-primary">Files</TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-primary">Settings</TabsTrigger>
            <TabsTrigger value="commands" className="data-[state=active]:bg-primary">Commands</TabsTrigger>
            <TabsTrigger value="broadcast" className="data-[state=active]:bg-primary">Broadcast</TabsTrigger>
          </TabsList>

          <TabsContent value="files">
            <div className="glass-card rounded-2xl border border-white/10 overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-white/5">
                    <TableHead className="text-muted-foreground">Filename</TableHead>
                    <TableHead className="text-muted-foreground">Available</TableHead>
                    <TableHead className="text-muted-foreground">Uploaded At</TableHead>
                    <TableHead className="text-right text-muted-foreground">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {files?.map((file) => (
                    <TableRow key={file.id} className="border-white/10 hover:bg-white/5 group">
                      <TableCell className="font-medium text-white">{file.filename}</TableCell>
                      <TableCell>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-white/5 border border-white/10">
                          {file.availableCount}
                        </span>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {file.createdAt ? new Date(file.createdAt).toLocaleDateString() : 'N/A'}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-muted-foreground hover:text-rose-500 hover:bg-rose-500/10"
                          onClick={() => handleDeleteFile(file.id)}
                          disabled={deleteFile.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="settings">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { id: 'bot_name', label: 'Bot Name', icon: <Bot className="w-4 h-4" /> },
                { id: 'support_text', label: 'Support Text', icon: <Heart className="w-4 h-4" /> },
                { id: 'otpgroup_text', label: 'OTP Group Text', icon: <Shield className="w-4 h-4" /> },
                { id: 'folder_text', label: 'Folder Link Text', icon: <Folder className="w-4 h-4" /> },
                { id: 'welcome_text', label: 'Welcome Message', icon: <Plus className="w-4 h-4" /> },
                { id: 'refresh_text', label: 'Refresh Button Text', icon: <Settings2 className="w-4 h-4" /> },
                { id: 'change_country_text', label: 'Change Country Text', icon: <Settings2 className="w-4 h-4" /> },
              ].map((field) => {
                const currentValue = settings?.find(s => s.key === field.id)?.value || '';
                return (
                  <div key={field.id} className="glass-card p-6 rounded-xl space-y-3">
                    <Label className="flex items-center gap-2 text-muted-foreground mb-2">
                      {field.icon}
                      {field.label}
                    </Label>
                    <div className="flex gap-2">
                      {field.id === 'welcome_text' ? (
                        <Textarea 
                          defaultValue={currentValue}
                          id={`input-${field.id}`}
                          className="bg-black/20 border-white/10 text-white min-h-[100px]"
                        />
                      ) : (
                        <Input 
                          defaultValue={currentValue}
                          id={`input-${field.id}`}
                          className="bg-black/20 border-white/10 text-white"
                        />
                      )}
                      <Button 
                        size="icon" 
                        className="bg-white/5 hover:bg-primary border border-white/10 shrink-0"
                        onClick={() => {
                          const val = (document.getElementById(`input-${field.id}`) as HTMLInputElement | HTMLTextAreaElement).value;
                          handleSettingUpdate(field.id, val);
                        }}
                      >
                        <Save className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="commands">
            <div className="space-y-6">
              <div className="glass-card p-6 rounded-xl space-y-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Plus className="w-5 h-5 text-primary" />
                  Add New Command
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Command (without /)</Label>
                    <Input 
                      placeholder="help" 
                      value={newCmd.command}
                      onChange={e => setNewCmd(prev => ({ ...prev, command: e.target.value }))}
                      className="bg-black/20 border-white/10"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Message</Label>
                    <Input 
                      placeholder="How can I help you?" 
                      value={newCmd.message}
                      onChange={e => setNewCmd(prev => ({ ...prev, message: e.target.value }))}
                      className="bg-black/20 border-white/10"
                    />
                  </div>
                </div>
                <Button 
                  onClick={() => addCommandMutation.mutate(newCmd)}
                  disabled={!newCmd.command || !newCmd.message || addCommandMutation.isPending}
                  className="w-full md:w-auto"
                >
                  {addCommandMutation.isPending ? "Adding..." : "Add Command"}
                </Button>
              </div>

              <div className="glass-card rounded-2xl border border-white/10 overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="border-white/10 hover:bg-white/5">
                      <TableHead className="text-muted-foreground">Command</TableHead>
                      <TableHead className="text-muted-foreground">Message</TableHead>
                      <TableHead className="text-right text-muted-foreground">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {commands?.map((cmd) => (
                      <TableRow key={cmd.id} className="border-white/10 hover:bg-white/5">
                        <TableCell className="font-mono text-primary font-bold">/{cmd.command}</TableCell>
                        <TableCell className="text-white max-w-md truncate">{cmd.message}</TableCell>
                        <TableCell className="text-right flex justify-end gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-muted-foreground hover:text-rose-500"
                            onClick={() => deleteCommandMutation.mutate(cmd.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="broadcast">
            <div className="glass-card p-8 rounded-2xl border border-white/10 space-y-6">
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Send className="w-6 h-6 text-primary" />
                  Send Broadcast
                </h3>
                <p className="text-muted-foreground text-sm">Send a message to all users who have interacted with the bot.</p>
              </div>
              
              <div className="space-y-4">
                <Textarea 
                  placeholder="Enter your message here (supports Markdown)..."
                  value={broadcastMsg}
                  onChange={e => setBroadcastMsg(e.target.value)}
                  className="bg-black/20 border-white/10 text-white min-h-[200px] text-lg"
                />
                <Button 
                  className="w-full py-6 text-lg font-bold gap-2"
                  disabled={!broadcastMsg || broadcastMutation.isPending}
                  onClick={() => {
                    if (confirm("Send this message to ALL users?")) {
                      broadcastMutation.mutate(broadcastMsg);
                    }
                  }}
                >
                  <Send className="w-5 h-5" />
                  {broadcastMutation.isPending ? "Sending..." : "Send Broadcast Now"}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
