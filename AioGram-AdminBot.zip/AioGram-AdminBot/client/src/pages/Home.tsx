import { useState } from "react";
import { Layout } from "@/components/Layout";
import { useFiles, useGetNumbers, useSettings } from "@/hooks/use-api";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, Download, Copy, Check, RefreshCw, Globe, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { data: files, isLoading } = useFiles();
  const { data: settings } = useSettings();
  const getNumbers = useGetNumbers();
  const { toast } = useToast();
  
  const [selectedFile, setSelectedFile] = useState<{ id: number; name: string } | null>(null);
  const [fetchedNumbers, setFetchedNumbers] = useState<string[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const refreshText = settings?.find(s => s.key === 'refresh_text')?.value || "Refresh Numbers 🔄";
  const countryText = settings?.find(s => s.key === 'change_country_text')?.value || "Change Country 🌍";

  const handleGetNumbers = async (fileId: number, filename: string) => {
    try {
      setSelectedFile({ id: fileId, name: filename });
      const data = await getNumbers.mutateAsync({ fileId });
      setFetchedNumbers(data.numbers);
    } catch (error: any) {
      toast({
        title: "Error fetching numbers",
        description: error.message,
        variant: "destructive",
      });
      setSelectedFile(null);
    }
  };

  const copyToClipboard = async (text: string, index: number) => {
    await navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    toast({
      description: "Number copied to clipboard",
    });
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header Section */}
        <div className="text-center max-w-2xl mx-auto space-y-4">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-gradient-primary">
            Premium Virtual Numbers
          </h1>
          <p className="text-muted-foreground text-lg">
            Instant access to high-quality virtual numbers for verification. Select a service below to get started.
          </p>
          
          <div className="flex items-center justify-center gap-3 pt-4">
            <Button variant="outline" className="gap-2 bg-white/5 border-white/10 hover:bg-white/10 text-white">
              <RefreshCw className="w-4 h-4" />
              {refreshText}
            </Button>
            <Button variant="outline" className="gap-2 bg-white/5 border-white/10 hover:bg-white/10 text-white">
              <Globe className="w-4 h-4" />
              {countryText}
            </Button>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-8">
          {files?.map((file) => (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ y: -5 }}
              transition={{ duration: 0.2 }}
            >
              <Card className="glass-card border-white/5 p-6 h-full flex flex-col justify-between group cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => handleGetNumbers(file.id, file.filename)}
              >
                <div>
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                      <MessageSquare className="w-6 h-6" />
                    </div>
                    {file.availableCount > 0 ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                        {file.availableCount} Available
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-500/10 text-rose-500 border border-rose-500/20">
                        Out of Stock
                      </span>
                    )}
                  </div>
                  
                  <h3 className="text-xl font-bold font-display mb-2 group-hover:text-primary transition-colors">
                    {file.filename.replace('.txt', '')}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Get fresh verification numbers instantly.
                  </p>
                </div>

                <Button 
                  className="w-full mt-6 bg-white/5 hover:bg-primary text-white border border-white/10 hover:border-transparent transition-all"
                  disabled={file.availableCount === 0}
                >
                  {getNumbers.isPending && selectedFile?.id === file.id ? (
                    "Fetching..."
                  ) : (
                    "Get Numbers"
                  )}
                </Button>
              </Card>
            </motion.div>
          ))}

          {files?.length === 0 && (
            <div className="col-span-full text-center py-12 text-muted-foreground">
              <p>No services available at the moment.</p>
            </div>
          )}
        </div>

        {/* Results Dialog */}
        <Dialog open={!!selectedFile && fetchedNumbers.length > 0} onOpenChange={(open) => !open && setSelectedFile(null)}>
          <DialogContent className="sm:max-w-md bg-zinc-950 border-white/10 text-white">
            <DialogHeader>
              <DialogTitle className="font-display text-xl">
                Your Numbers: {selectedFile?.name.replace('.txt', '')}
              </DialogTitle>
              <DialogDescription className="text-muted-foreground">
                Copy these numbers to use them. They have been removed from the list.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-3 py-4">
              {fetchedNumbers.map((num, idx) => (
                <div 
                  key={idx} 
                  className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:border-primary/50 transition-colors group"
                >
                  <code className="font-mono text-lg font-medium tracking-wider text-primary">
                    {num}
                  </code>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 w-8 p-0 text-muted-foreground hover:text-white"
                    onClick={() => copyToClipboard(num, idx)}
                  >
                    {copiedIndex === idx ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              ))}
            </div>
            
            <div className="flex justify-end pt-2">
              <Button onClick={() => setSelectedFile(null)} className="w-full bg-primary hover:bg-primary/90">
                Done
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
