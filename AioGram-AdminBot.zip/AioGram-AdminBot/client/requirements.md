## Packages
framer-motion | For smooth page transitions and card animations
lucide-react | For beautiful icons
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
  mono: ["'Fira Code'", "monospace"],
}
