import { z } from 'zod';
import { insertSettingSchema, insertFileSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  settings: {
    list: {
      method: 'GET' as const,
      path: '/api/settings',
      responses: {
        200: z.array(z.object({ key: z.string(), value: z.string() })),
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/settings/:key',
      input: z.object({ value: z.string() }),
      responses: {
        200: z.object({ key: z.string(), value: z.string() }),
        404: errorSchemas.notFound,
      },
    },
  },
  files: {
    list: {
      method: 'GET' as const,
      path: '/api/files',
      responses: {
        200: z.array(z.object({
          id: z.number(),
          filename: z.string(),
          createdAt: z.string().nullable(),
          availableCount: z.number()
        })),
      },
    },
    upload: {
      method: 'POST' as const,
      path: '/api/files',
      // Multipart form data is handled separately, but this documents the intent
      input: z.any(), 
      responses: {
        201: z.object({ id: z.number(), filename: z.string() }),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/files/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  numbers: {
    get: {
      method: 'POST' as const,
      path: '/api/numbers/get',
      input: z.object({ fileId: z.number() }),
      responses: {
        200: z.object({ numbers: z.array(z.string()) }),
        404: errorSchemas.notFound, // File not found or no numbers left
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
