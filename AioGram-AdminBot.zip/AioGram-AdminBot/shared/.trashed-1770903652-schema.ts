import { pgTable, text, serial, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Configuration settings (bot name, support text, etc.)
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(), // e.g., 'bot_name', 'support_text'
  value: text("value").notNull(),
});

// Uploaded files (categories of numbers)
export const numberFiles = pgTable("number_files", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(), // The original filename or display name
  createdAt: timestamp("created_at").defaultNow(),
});

// The actual numbers imported from files
export const numbers = pgTable("numbers", {
  id: serial("id").primaryKey(),
  fileId: integer("file_id").notNull(), // References numberFiles.id
  content: text("content").notNull(), // The phone number or line of text
  isUsed: boolean("is_used").default(false).notNull(),
  usedAt: timestamp("used_at"),
});

// Relations
export const numberFilesRelations = relations(numberFiles, ({ many }) => ({
  numbers: many(numbers),
}));

export const numbersRelations = relations(numbers, ({ one }) => ({
  file: one(numberFiles, {
    fields: [numbers.fileId],
    references: [numberFiles.id],
  }),
}));

// Schemas
export const insertSettingSchema = createInsertSchema(settings).omit({ id: true });
export const insertFileSchema = createInsertSchema(numberFiles).omit({ id: true, createdAt: true });
export const insertNumberSchema = createInsertSchema(numbers).omit({ id: true, isUsed: true, usedAt: true });

// Types
export type Setting = typeof settings.$inferSelect;
export type NumberFile = typeof numberFiles.$inferSelect;
export type PhoneNumber = typeof numbers.$inferSelect;

export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type InsertNumberFile = z.infer<typeof insertFileSchema>;
export type InsertPhoneNumber = z.infer<typeof insertNumberSchema>;

// API Payload Types
export type UpdateSettingRequest = { value: string };
export type GetNumbersResponse = { numbers: string[] }; // Array of 3 numbers
export type FileStats = NumberFile & { availableCount: number };

// Custom commands managed by admin
export const commands = pgTable("commands", {
  id: serial("id").primaryKey(),
  command: text("command").notNull().unique(), // e.g., 'help', 'info'
  message: text("message").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

export const insertCommandSchema = createInsertSchema(commands).omit({ id: true });
export type Command = typeof commands.$inferSelect;
export type InsertCommand = z.infer<typeof insertCommandSchema>;

// User database for tracking Telegram users
export const botUsers = pgTable("bot_users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

export const insertBotUserSchema = createInsertSchema(botUsers).omit({ id: true, joinedAt: true });
export type BotUser = typeof botUsers.$inferSelect;
export type InsertBotUser = z.infer<typeof insertBotUserSchema>;

export * from "./models/chat";
